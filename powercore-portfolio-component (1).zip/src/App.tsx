/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useSpring, useTransform } from 'motion/react';
import { Cpu, Zap, Terminal } from 'lucide-react';

// --- Components ---

const CircuitPattern = ({ isActive }: { isActive: boolean }) => {
  return (
    <svg className="absolute inset-0 w-full h-full opacity-20 pointer-events-none" viewBox="0 0 400 300">
      <defs>
        <filter id="glow">
          <feGaussianBlur stdDeviation="2.5" result="coloredBlur" />
          <feMerge>
            <feMergeNode in="coloredBlur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      <g stroke={isActive ? "#22c55e" : "#333"} strokeWidth="1" fill="none">
        <motion.path
          d="M 50 50 L 150 50 L 150 100 L 250 100"
          animate={{
            strokeDashoffset: isActive ? [100, 0] : 100,
            stroke: isActive ? "#22c55e" : "#333",
            filter: isActive ? "url(#glow)" : "none"
          }}
          transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
          className="energy-line"
        />
        <motion.path
          d="M 50 250 L 100 250 L 100 150 L 200 150"
          animate={{
            strokeDashoffset: isActive ? [100, 0] : 100,
            stroke: isActive ? "#22c55e" : "#333",
            filter: isActive ? "url(#glow)" : "none"
          }}
          transition={{ repeat: Infinity, duration: 2, ease: "linear", delay: 0.5 }}
          className="energy-line"
        />
        <motion.circle
          cx="250" cy="100" r="3"
          fill={isActive ? "#22c55e" : "#333"}
          animate={{ opacity: isActive ? [0.4, 1, 0.4] : 0.3 }}
          transition={{ repeat: Infinity, duration: 1 }}
        />
      </g>
    </svg>
  );
};

const StatusLabel = ({ label, value, isActive }: { label: string, value: string, isActive: boolean }) => (
  <div className="flex flex-col gap-1">
    <span className="text-[10px] uppercase tracking-widest text-zinc-500 font-mono">{label}</span>
    <span className={`text-xs font-mono transition-colors duration-500 ${isActive ? 'text-green-400' : 'text-zinc-600'}`}>
      {isActive ? value : 'OFFLINE'}
    </span>
  </div>
);

export default function App() {
  const [isPlugged, setIsPlugged] = useState(false);
  const [isPoweringUp, setIsPoweringUp] = useState(false);
  const [metrics, setMetrics] = useState({ requests: 0, load: 0, uptime: 99.982 });

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPoweringUp) {
      interval = setInterval(() => {
        setMetrics(prev => ({
          requests: Math.floor(Math.random() * 500) + 1200,
          load: Math.floor(Math.random() * 15) + 42,
          uptime: Math.min(99.999, prev.uptime + 0.0001)
        }));
      }, 100);
    } else {
      setMetrics({ requests: 0, load: 0, uptime: 99.982 });
    }
    return () => clearInterval(interval);
  }, [isPoweringUp]);

  const handleInteractionStart = () => {
    setIsPlugged(true);
    setTimeout(() => setIsPoweringUp(true), 450);
  };

  const handleInteractionEnd = () => {
    setIsPlugged(false);
    setIsPoweringUp(false);
  };

  return (
    <div 
      className="relative w-full h-screen bg-[#020202] text-white overflow-hidden flex items-center justify-center select-none perspective-[2000px]"
      onMouseDown={handleInteractionStart}
      onMouseUp={handleInteractionEnd}
      onMouseLeave={handleInteractionEnd}
      onTouchStart={handleInteractionStart}
      onTouchEnd={handleInteractionEnd}
    >
      {/* Environmental Lighting */}
      <div className="absolute inset-0 dot-grid opacity-10 pointer-events-none" />
      <div className="absolute inset-0 bg-radial-[at_50%_40%] from-green-500/5 to-transparent pointer-events-none" />

      {/* Main 3D Stage */}
      <motion.div 
        style={{ transformStyle: 'preserve-3d' }}
        animate={{ 
          rotateX: isPoweringUp ? 32 : 35, 
          rotateZ: isPoweringUp ? -4 : -5,
          y: isPoweringUp ? 10 : 0
        }}
        className="relative flex items-center justify-center transition-all duration-700 ease-out"
      >
        
        {/* The Hardware Module (3D Card) */}
        <motion.div 
          className="relative w-[440px] h-[300px] bg-zinc-950 rounded-2xl border-t border-l border-zinc-700 flex flex-col p-8 overflow-hidden"
          style={{ 
            boxShadow: `
              -8px 8px 0px #09090b,
              -20px 20px 40px rgba(0,0,0,0.8),
              ${isPoweringUp ? '0 0 80px -20px rgba(0, 255, 65, 0.3)' : 'none'}
            `,
            transformStyle: 'preserve-3d'
          }}
        >
          {/* Internal Glowing Core (Preserve 3D) */}
          <div className="absolute inset-0 bg-radial-[at_20%_30%] from-zinc-900/40 to-transparent pointer-events-none" />
          <CircuitPattern isActive={isPoweringUp} />

          {/* Module Content */}
          <div className="relative z-10 space-y-6">
            <header className="flex justify-between items-start">
              <div className="space-y-1">
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${isPoweringUp ? 'bg-[#00FF41] shadow-[0_0_10px_#00FF41]' : 'bg-zinc-800'}`} />
                  <h2 className="text-xl font-bold tracking-tighter text-zinc-100 uppercase">Synapse_B12</h2>
                </div>
                <p className="text-[10px] font-mono text-zinc-500 tracking-[0.2em] uppercase">Core Backend Engine</p>
              </div>
              <Terminal className={`w-5 h-5 ${isPoweringUp ? 'text-green-500' : 'text-zinc-700'}`} />
            </header>

            {/* Live Metrics */}
            <div className="grid grid-cols-2 gap-y-6 gap-x-12 pt-8 border-t border-zinc-900">
              <MetricItem 
                label="Stream_Rate" 
                value={`${metrics.requests}`} 
                unit="REQ/S" 
                isActive={isPoweringUp} 
              />
              <MetricItem 
                label="CPU_Load" 
                value={`${metrics.load}`} 
                unit="%" 
                isActive={isPoweringUp} 
              />
              <MetricItem 
                label="Uptime" 
                value={metrics.uptime.toFixed(3)} 
                unit="%" 
                isActive={isPoweringUp} 
              />
              <MetricItem 
                label="Nodes" 
                value={isPoweringUp ? "12/12" : "0/12"} 
                unit="ONLINE" 
                isActive={isPoweringUp} 
              />
            </div>
          </div>

          {/* Connection Slot (Visual cutout depth) */}
          <div className="absolute right-0 top-1/2 -translate-y-1/2 w-8 h-24 bg-black border-l border-zinc-800 flex items-center justify-end pr-1">
            <div className={`w-1 h-12 rounded-full transition-colors duration-500 ${isPoweringUp ? 'bg-[#00FF41]' : 'bg-zinc-900'}`} />
          </div>
        </motion.div>

        {/* The Power Connector (3D Plug) */}
        <div className="relative ml-[-20px] translate-z-[40px]" style={{ transformStyle: 'preserve-3d' }}>
          <motion.div
            animate={{ 
              x: isPlugged ? -25 : 80,
              z: isPlugged ? -10 : 0,
              rotateY: isPlugged ? 0 : -5
            }}
            transition={{ type: "spring", stiffness: isPlugged ? 180 : 120, damping: 20 }}
            className="flex items-center"
            style={{ transformStyle: 'preserve-3d' }}
          >
            {/* The main plug body with 3D depth */}
            <div 
              className="relative w-40 h-28 bg-zinc-900 border border-zinc-700 rounded-xl flex items-center justify-center overflow-hidden"
              style={{
                boxShadow: `
                  -15px 15px 30px rgba(0,0,0,0.6),
                  ${isPoweringUp ? '0 0 40px -5px rgba(0, 255, 65, 0.2)' : 'none'}
                `,
                transformStyle: 'preserve-3d'
              }}
            >
              {/* Energy Rail */}
              <div className={`w-3 h-full transition-all duration-500 absolute left-0 ${isPoweringUp ? 'bg-[#00FF41] shadow-[0_0_20px_#00FF41]' : 'bg-zinc-800'}`} />
              
              <div className="px-8 space-y-2 text-center">
                <Zap className={`w-8 h-8 mx-auto transition-colors duration-500 ${isPoweringUp ? 'text-[#00FF41] drop-shadow-[0_0_10px_#00FF41]' : 'text-zinc-600'}`} />
                <div className="space-y-0.5">
                  <div className="text-[8px] font-mono text-zinc-500 tracking-tighter uppercase whitespace-nowrap">Source_Prime_A</div>
                  <div className={`text-[9px] font-bold tracking-widest uppercase transition-colors ${isPoweringUp ? 'text-white' : 'text-zinc-700'}`}>
                    Active_Source
                  </div>
                </div>
              </div>

              {/* Side Panels (Fake 3D Depth) */}
              <div className="absolute right-0 top-0 bottom-0 w-[1px] bg-zinc-100/10" />
            </div>

            {/* Connector Pin (Hidden when inserted) */}
            <div className="absolute left-[-15px] top-1/2 -translate-y-1/2 w-16 h-12 bg-zinc-400 rounded-l-md -z-10" />

            {/* Spark Emission */}
            <AnimatePresence>
              {isPlugged && !isPoweringUp && (
                <motion.div 
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: [0, 2, 0], opacity: [0, 1, 0] }}
                  className="absolute left-[-30px] top-1/2 -translate-y-1/2 w-10 h-10 bg-white rounded-full blur-md z-30"
                />
              )}
            </AnimatePresence>

            {/* Cable trailing back into distance - NOW INSIDE motion.div to follow movement */}
            <div className="absolute left-full top-1/2 -translate-y-1/2 pl-0 pointer-events-none">
              <div className="w-[800px] h-3 bg-gradient-to-r from-zinc-800 to-transparent" />
            </div>
          </motion.div>
        </div>

      </motion.div>

      {/* Floating Meta Labels */}
      <div className="absolute top-12 left-12 space-y-1">
        <h1 className="text-4xl font-bold tracking-tighter">ELIAS_VANCE</h1>
        <p className="font-mono text-[9px] text-[#00FF41] uppercase tracking-[0.4em]">Systems Engineering // Backend Architect</p>
      </div>

      <div className="absolute bottom-12 right-12 text-right">
        <p className="text-[9px] font-mono text-zinc-600 uppercase tracking-widest mb-2">Protocol Deployment v4.0</p>
        <div className="flex gap-4 justify-end">
          <div className="w-8 h-1 bg-zinc-900 overflow-hidden">
            <motion.div 
              className="h-full bg-green-500"
              animate={{ width: isPoweringUp ? '100%' : '0%' }}
            />
          </div>
          <div className="w-8 h-1 bg-zinc-900" />
        </div>
      </div>

      <div className="absolute bottom-12 left-12 flex items-center gap-4">
        <div className={`w-2 h-2 rounded-full ${isPoweringUp ? 'animate-pulse bg-green-500' : 'bg-zinc-800'}`} />
        <span className="text-[10px] font-mono text-zinc-500 tracking-widest uppercase">
          {isPoweringUp ? 'System Online: All Sectors Functional' : 'Idle State: Awaiting Power Handshake'}
        </span>
      </div>
    </div>
  );
}

const MetricItem = ({ label, value, unit, isActive }: { label: string, value: string, unit: string, isActive: boolean }) => (
  <div className="space-y-1">
    <div className="text-[9px] font-mono text-zinc-600 uppercase tracking-widest leading-none">{label}</div>
    <div className="flex items-baseline gap-1.5 leading-none">
      <motion.span 
        key={value}
        initial={{ y: 5, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className={`text-lg font-bold tracking-tighter transition-colors duration-500 ${isActive ? 'text-white' : 'text-zinc-800'}`}
      >
        {isActive ? value : '---'}
      </motion.span>
      <span className={`text-[8px] font-mono transition-colors duration-500 ${isActive ? 'text-[#00FF41]' : 'text-zinc-800'}`}>
        {unit}
      </span>
    </div>
  </div>
);
